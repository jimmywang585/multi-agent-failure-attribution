from __future__ import annotations
import os
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline

# Reduce fragmentation; harmless if already set
os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")

def _prefer_bf16() -> torch.dtype:
    if torch.cuda.is_available():
        # A100s handle bf16 natively; falls back to fp16 if not supported
        return torch.bfloat16
    return torch.float32

def build_generator(model_name: str):
    """
    Build a text-generation pipeline that:
      - uses bf16 on CUDA (fast/stable on A100), fp32 on CPU
      - uses SDPA attention where available
      - lets Accelerate place layers with device_map='auto' (prevents OOM)
    """
    dtype = _prefer_bf16()
    tok = AutoTokenizer.from_pretrained(model_name, use_fast=True)

    # model_max_length is respected during encoding; we also truncate in run_rating
    kwargs = dict(
        torch_dtype=dtype,
        device_map="auto",             # offload if needed instead of OOM
        attn_implementation="sdpa",    # better mem profile on newer PyTorch
        trust_remote_code=False,
    )
    model = AutoModelForCausalLM.from_pretrained(model_name, **kwargs)

    gen = pipeline(
        "text-generation",
        model=model,
        tokenizer=tok,
        # framework='pt' (implicit)
    )
    return gen, tok


@torch.inference_mode()
def run_rating(gen, tok, prompt: str, max_new_tokens: int, temperature: float, top_p: float):
    """
    - Forced greedy (do_sample=False). Temperature/top_p are common no-ops for many chat models
      and can cause extra memory use; we keep the signature to avoid config surgery.
    - Hard-truncate inputs to the model’s max length to avoid KV cache explosions.
    - On CUDA OOM, retry once on CPU for this call only (keeps training flowing).
    """
    # Respect the tokenizer limit; leave headroom for the small generation
    model_max = getattr(tok, "model_max_length", 4096)
    enc = tok(prompt, truncation=True, max_length=max(256, model_max - max_new_tokens - 16), return_tensors="pt")

    try:
        out = gen(
            enc.input_ids.to(gen.device),
            attention_mask=enc.attention_mask.to(gen.device),
            max_new_tokens=max_new_tokens,
            do_sample=False,           # deterministic scoring stub
            pad_token_id=tok.eos_token_id,
        )[0]["generated_text"]
        return out
    except torch.cuda.OutOfMemoryError:
        # One-shot CPU fallback for this request only
        torch.cuda.empty_cache()
        local_gen = pipeline(
            "text-generation",
            model=gen.model.to("cpu"),
            tokenizer=gen.tokenizer,
        )
        out = local_gen(
            enc.input_ids,
            attention_mask=enc.attention_mask,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            pad_token_id=tok.eos_token_id,
        )[0]["generated_text"]
        # put back for the next call
        if torch.cuda.is_available():
            gen.model.to("cuda")
        return out